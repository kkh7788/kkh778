/*Kaihang Hao 400556802  05/03/2025
This is the js part of the canvas assignment Created three categories 
and a draw method*/
let c = document.getElementById("myCanvas");
let ctx = c.getContext("2d");
let shapes = [];
let currentColor = "black";
let currentShape = "rectangle";
let shapeSelector = document.getElementById("shape_selector");
let colorSelector = document.getElementById("choose_color");
let clearButton = document.getElementById("clear");
let undoButton = document.getElementById("undo");
let drawButton = document.getElementById("draw");
let newShape 
let sizeSelector = document.getElementById("size_selector")
let currentSize = "mid";
let sizeMap = {small : 20, mid : 40, big : 70
};
/**
 the purpose of those threefunction is The purpose of these three classes
  is to define the shape and accept the sizeTYpe parameter
 */
class Rectangle {
    constructor(x, y, color, sizeType){
        this.x = x;
        this.y = y;
        this.type = "rectangle";
        this.width = sizeMap[sizeType];
        this.height = sizeMap[sizeType];
        this.color = color;
        this.sizeType = sizeType;
    }
    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}
class Circle {
    constructor(x, y, color, sizeType){
        this.x = x;
        this.y = y;
        this.type = "circle";
        this.radius = sizeMap[sizeType];
        this.sizeType = sizeType;
        this.color = color;
    }
    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI*2);
        ctx.fill();
    }
}
class Triangle {
    constructor(x, y, color, sizeType){
        this.x = x;
        this.y = y;
        this.sizeType = sizeType;
        this.size = sizeMap[sizeType];
        this.type = "triangle";
        this.color = color;
    }
    draw(ctx) {
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(this.x + this.size, this.y);
        ctx.lineTo(this.x + this.size/2, this.y - this.size*(Math.sqrt(3)/2));
        ctx.closePath();
        ctx.fill();

    }
}
/*
1.purpose：The purpose is to redraw the drawing board. When you click undo, 
        it will delete all the patterns except the latest one and redraw the rest.
2. clearRect Clear all elements. Use forloop to add patterns to the canvas one by one
3..Returns a new canvas pattern combination
*/
function redraw(){
    ctx.clearRect(0, 0, c.width, c.height );
    if (shapes.length > 0) {
        for (let i = 0; i< shapes.length; i++) {
            shapes[i].draw(ctx);
        }

    }
   
}
/*
1.Listen to user operations and respond when selecting
 different options or clicking on the canvas
2.Use if to determine which pattern the user has selected,
 and add the pattern to the list in preparation for undo. Then save it locally
*/
sizeSelector.addEventListener("change",function(event){
currentSize = event.target.value
})
shapeSelector.addEventListener("change", function(event){
    currentShape = event.target.value;
});

colorSelector.addEventListener("input", function(event){
    currentColor = event.target.value;
})

c.addEventListener("click", function(event){
    let x = event.pageX - this.offsetLeft;
    let y = event.pageY - this.offsetTop;
    if (currentShape === "rectangle") {
        newShape = new Rectangle(x, y, currentColor, currentSize);
    } else if (currentShape === "circle") {
        newShape = new Circle(x, y, currentColor, currentSize);
    } else if (currentShape === "triangle") {
        newShape = new Triangle(x, y, currentColor, currentSize);
    }
    shapes.push(newShape);
    saveToLocalStorage();
    redraw();
})
/*
1.The purpose is to monitor the undo and clear buttons. When the user clicks undo, 
the last element added to the list is pushed out and the drawing board is redrawn. When clear is selected,
 the list is cleared and the drawing board is redrawn.

*/
undoButton.addEventListener("click", function(event){
    if (shapes.length > 0) {
        shapes.pop();
        saveToLocalStorage();
        redraw();
    }
})
clearButton.addEventListener("click", function(event){
    shapes = [];
    saveToLocalStorage();
    redraw();
})
/*The purpose is to save the content on the canvas locally 
so that the content will be retained when you open the website next time.
Use json to store structured text and use if statements to determine the storage type
*/
function saveToLocalStorage() {
    let dataToSave = shapes.map(function(shape) {
      return {type: shape.type, x: shape.x, y: shape.y, color: shape.color,sizeType: shape.sizeType};
    });
    localStorage.setItem("shapes", JSON.stringify(dataToSave));
  }
  if (localStorage.getItem("shapes")) {
    let savedShapes = JSON.parse(localStorage.getItem("shapes"));
    currentSize = savedShapes[0].sizeType || "mid";
    shapes = savedShapes.map(function(item) {
      if (item.type === "rectangle") {
        return new Rectangle(item.x, item.y, item.color, item.sizeType);
      } else if (item.type === "circle") {
        return new Circle(item.x, item.y, item.color, item.sizeType);
      } else if (item.type === "triangle") {
        return new Triangle(item.x, item.y, item.color, item.sizeType);
      }
    });
    redraw();
  }
  